let anc=
		<div>
			<div id="null"></div>
            <a class="line" href="page1.html">MKX Characters' Index App</a>
        </div>;
ReactDOM.render(anc,document.getElementById("r"));